	
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
		<base href="/" />
		<title>Myanmar Futurocoin Network on jungonet</title>
		<link href="https://fonts.googleapis.com/css?family=Orbitron:400,700,900,500|Pridi|Didact+Gothic|Nixie+One|Sacramento|Pacifico|Nunito|Lato:400,700,900|Muli|Varela+Round" rel="stylesheet" type="text/css">

		<link rel="stylesheet" href="public/css/fonts/font-awesome-4.7.0/css/font-awesome.min.css">

		<link href="public/css/main.css" rel="stylesheet" type="text/css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
		<script src="//ajax.googleapis.com/ajax/libs/dojo/1.12.1/dojo/dojo.js"></script>
		<script src="public/js/lib/viewport.js"></script>

		<script src="public/js/main.js"></script>
		<script src="public/js/video.player.js"></script>
		<link rel="apple-touch-icon" sizes="180x180" href="/favicons/apple-touch-icon.png">
		<link rel="icon" type="image/png" href="/favicons/favicon-32x32.png" sizes="32x32">
		<link rel="icon" type="image/png" href="/favicons/favicon-16x16.png" sizes="16x16">
		<link rel="manifest" href="/favicons/manifest.json">
		<link rel="mask-icon" href="/favicons/safari-pinned-tab.svg" color="#5bbad5">
		<meta name="theme-color" content="#ffffff">
		<meta name="description" content="အားလုံးပဲ မဂၤလာပါ, Myanmar Futurocoin Network မွ ေႏြးေထြးစြာႀကိဳဆိုပါတယ္....">
       <style>
	
    #profile-data span i {
    color: #fff;
}

.tooltip .tooltiptext a:hover, .blue, a {
    text-decoration: none;
    color: #3B5998;
}
header {
    background: #3B5998 !important;
    }
.centre-hashtag,.btn-holder{
    background: #3B5998 !important;
}
 .btn{
	background: #3B5998 !important;
	}  
.hashtags-trending a {
    background: #3B5998 !important;

}	  
</style>	</head>
		<body data-user=""
		  data-page="2"
		data-network="myanmarfuturocoin">
		<header id="header">

			<div class="row-wrap">
				<div id="logo" class="network-logo">
										<a href="http://myanmarfuturocoin.jungonet.com" style="color:white">Myanmar Futurocoin Network</a>
									</div>


				<menu id="big-screen-menu">
				<span id="new-posts"></span>
				<a href="signup">Signup to myanmarfuturocoin</a> <a href="login">Login</a>				</menu>


				<div id="search-box">
					<form id="search_form" onsubmit="return false;">
	<label for="srch"><i aria-hidden="true" class="fa fa-search"></i><span class="sr-only">Search icons</span></label>
	<input type="text" id="srch" name="search" value="" placeholder="Search here" >
	<input type="hidden" id="srch_network" name="network" value="" >
	
</form>				</div>


			</div>

		</header>
<div id="site-container">


<div class="row-wrap">
<style>#profile-cover{background: url(public/images/covers/1530129041KlVVL.jpg)}</style>
<div id="profile-cover">
					<div id="profile-pic" class="network_avatar">
					<img src="public/images/avatar/1530128204D1vRF.png" class="circular_200 net_avatar">
				</div>
				<div id="profile-data">
										<h1>myanmarfuturocoin@jungonet</h1>
										<span>
					 <a href="users"><i class="fa fa-users" aria-hidden="true"></i></a> 1					</span>
										<span>
					 <a href=""><i class="fa fa-comments-o" aria-hidden="true"></i></a> 0					</span>
										<span>
					 <a href="photos"><i class="fa fa-picture-o" aria-hidden="true"></i></a> 0					</span>
					<span>
					 <a href="videos"><i class="fa fa-video-camera" aria-hidden="true"></i></a> 0					</span>
										
					<span id="about-btn">
					 <i class="fa fa-info-circle" aria-hidden="true"></i> About
					 <span id="about-this-network" class="hidden">
					 <strong>Myanmar Futurocoin Network</strong> - အားလုံးပဲ မဂၤလာပါ, Myanmar Futurocoin Network မွ ေႏြးေထြးစြာႀကိဳဆိုပါတယ္....					 </span>
					</span>
					
									</div>
			
</div>

</div>

<div class="row-wrap">
<div class="side-left colmns">
<div class="data-holder">
<h2> <i class="fa fa-users" aria-hidden="true"></i> Members <span class="total-number">(1)</span> <i aria-hidden="true" class="fa fa-search" style="float: right;margin-top: 4px"></i></h2>
<ul>
	</ul>
</div>
<div class="data-holder">
	<div class="padding-10 small">
	&copy; 2016 jungonet.com <br>
<a href="/about/help/">About</a> | <a href="/about/help/">Help</a> | <a href="/about/terms_and_conditions/">Terms</a> | <a href="/about/privacy_policy">Privacy Policy</a> | <a href="/about/cookie_policy/">Cookies</a>
	</div>
</div>
</div><div class="main-container colmns">
	
<form id="deleteForm" class="hidden">
	<input type="hidden" name="post" id="post_dl" value="">
</form>
<form id="likeForm" class="hidden">
	<input type="hidden" name="post" id="like_post" value="">
</form>
<form id="flagForm" class="hidden">
	<input type="hidden" name="post" id="flag_post" value="">
</form>
<form id="likeComForm" class="hidden">
	<input type="hidden" name="post" id="like_comment" value="">
</form>
	<div class="data-holder">
		<div class="padding-10">
			<h2>There are no posts in this network, be the first to post something</h2>
		</div>
	</div>
			</div>
<div class="side-right colmns">
	<div class="btn-holder">
<div>
	   <a href="signup" class="padding-10"><i class="fa fa-user-plus" aria-hidden="true"></i> Create New Network</a>
</div>
</div>
<div class="data-holder">
<h2 class="padding-10"><i class="fa fa-envelope-o fa-fw"></i> Invite Friend/s</h2>
<div class="padding-10">
	
	Invite a friend. To share this website with a friend, simply fill out their e-mail address below and then click Send Invite.
	<div class="padding-10"></div>
	
	<form class="sidebar-form" id="send_invite" onsubmit="return false;">
		<input type="text" value="" placeholder="Enter email" name="email" id="invite-email" class="form-input margin-btn10">
				<input type="hidden" name="network" value="myanmarfuturocoin">
				<div class="center-align" id="invite-btn-holder">
		 <button type="button" class="btn" id="invite-btn">Send Invite</button>
		</div>
	</form>
	
</div>

</div><div class="data-holder">
<h2> <i class="fa fa-hashtag" aria-hidden="true"></i> Trending Hashtag</h2>
<ul class="padding-10">
		<li class="hashtags-trending"><a href="hashtag/MugabeMustGo">#MugabeMustGo</a></li>
		<li class="hashtags-trending"><a href="hashtag/Tajamuka">#Tajamuka</a></li>
		<li class="hashtags-trending"><a href="hashtag/Zimbabwe">#Zimbabwe</a></li>
		<li class="hashtags-trending"><a href="hashtag/GraceMugabe">#GraceMugabe</a></li>
		<li class="hashtags-trending"><a href="hashtag/AsifuniBumbulu">#AsifuniBumbulu</a></li>
		<li class="hashtags-trending"><a href="hashtag/Nera">#Nera</a></li>
		<li class="hashtags-trending"><a href="hashtag/Zimbabwecoup">#Zimbabwecoup</a></li>
		<li class="hashtags-trending"><a href="hashtag/Mthwakazi!,">#Mthwakazi!,</a></li>
		<li class="hashtags-trending"><a href="hashtag/Mugabe">#Mugabe</a></li>
		<li class="hashtags-trending"><a href="hashtag/TytanEP">#TytanEP</a></li>
		
</ul>
</div>
<div class="data-holder">
<h2> <i class="fa fa-image" aria-hidden="true"></i> Trending Photos</h2>
<div class="padding-10">
	
		
</div>
</div><div class="data-holder">
<h2> <i class="fa fa-video-camera" aria-hidden="true"></i> Trending Videos</h2>

	
	</div>

</div>	
</div>
</div>


		<footer>
			<div class="row-wrap">
			<div class="padding-10 small">

<a href="/about/help/">Help</a> | <a href="/about/terms_and_conditions/">Terms & Conditions</a> | <a href="/about/Privacy_Policy/">Privacy</a> | <a href="/about/Cookie_Policy/">Cookies</a> | &copy;2016 jungonet.com, Powered by <a href="http://jungonet.com/" target="_blank" style="margin-left: 0">JungoNet</a>
	</div>			</div>
		</footer>


		<div id="lightbox">

			<div id="about-info" class="small-form  small-form-background">
								<h1 id="about-logo">jungonet</h1>
				<div id="version">Version 1.02</div>
				<div id="network-info"></div>

							</div>

			<form class="small-form  small-form-background" id="loginForm">
        <div class="title-text">
	        	        
	        <h2 class="title title-2">Sign in to use myanmarfuturocoin</h2>
	                </div>
        <div class="form-group">
            <label class="form-label">
	            <span class="form-name">Email</span> 
	            <input type="email" name="email" class="form-input" value="" required>
            </label>
        </div>
        
        <div class="form-group">
            <label class="form-label">
	            <span class="form-name">Password</span> 
	            <input type="password" name="password" class="form-input" value="" required>
            </label>
        </div>
        <div class="small-form-submit form-group">
            <button class="btn btn-primary" type="button" id="login-btn" >Log In</button>
            
        </div>
        <div class="small-form-terms form-group">
            <a href="/forgot_password/">Forgot password?</a>
        </div>
        <div id="response"></div>
                <div class="small-form-submit form-group" style="font-weight: bold">
            Don't have an account? <button class="btn btn-primary" type="button" id="signup-btn" onclick="location.href='/signup'" >Create one!</button>
            
        </div>
        </form>

		</div>
	</body>
	</html>
